function fullTextOrLoad(task,data){
	
	if($("#texto").html().length == HtmlSanitizer.SanitizeHtml(data.text.replace(/\\n/g, "<br>")).length){
		if(data.noFadeOut != undefined){
			if(!data.noFadeOut){
				$("#canvas").fadeOut(fadeSpeed,undefined, () => {
						
						if(data.value != undefined)
							setKey(data.key,data.value);
						else if(data.add != undefined)
							addToKey(data.key,data.add);
						else if(data.substract != undefined)
							substractToKey(data.key,data.substract);
						
						if(data.branching == undefined)
							if(data.target != undefined){
								data.target = replaceTokensForValue(data.target);
								loadScript(data.target);
							}else
								return;
						else
							loadScript(resolveBranch(data.branching));
					} );
			}else{
				if(data.value != undefined)
					setKey(data.key,data.value);
				else if(data.add != undefined)
					addToKey(data.key,data.add);
				else if(data.substract != undefined)
					substractToKey(data.key,data.substract);
				
				if(data.branching == undefined)
					if(data.target != undefined){
						data.target = replaceTokensForValue(data.target);
						loadScript(data.target);
					}else
						return;
				else
					loadScript(resolveBranch(data.branching));
			}
		}else{
			$("#canvas").fadeOut(fadeSpeed,undefined, () => {
					
					if(data.value != undefined)
						setKey(data.key,data.value);
					else if(data.add != undefined)
						addToKey(data.key,data.add);
					else if(data.substract != undefined)
						substractToKey(data.key,data.substract);
					
					if(data.branching == undefined)
						if(data.target != undefined){
							data.target = replaceTokensForValue(data.target);
							loadScript(data.target);
						}else
							return;
					else
						loadScript(resolveBranch(data.branching));
				} );			
		}
			
	}else{
		clearInterval(task);
		$("#texto").html(HtmlSanitizer.SanitizeHtml(data.text.replace(/\\n/g, "<br>")));
	}
	
}

function setKey(key,value){
	
	if(key != undefined){
		if(value == "undefined")
			value = undefined;
		userStorage[key] = value;
	}
	
}

function addToKey(key,delta){
	if(key != undefined){
		if(userStorage[key] != undefined)
			userStorage[key] += value;
		else
			userStorage[key] = value;
	}
}

function substractToKey(key,delta){
	if(key != undefined){
		if(userStorage[key] != undefined)
			userStorage[key] -= value;
		else
			userStorage[key] = value;
	}
}

function renderText(textObject,textString){
	
	do{
		if(textObject.html().length != textString.length){
			if(textObject.html().length+3 <= textString.length){
				if(textString.charAt(textObject.html().length) == "<"){
					if(textString.substring(textObject.html().length,textObject.html().length+4).includes("<br>")){
						textObject.html(textString.substring(0,textObject.html().length+4));
						return;
					}
				}
				textObject.html(textString.substring(0,textObject.html().length+1));
			}else{
				textObject.html(textString.substring(0,textObject.html().length+1));
			}
		}
	}while(textString.substring(textObject.html().length,textObject.html().length+1) == " ");
	
	
}

function replaceTokensForValue(string){
	
	while(string.indexOf("<") != -1){
		
		let start = string.indexOf("<");
		let end = string.indexOf(">");
		
		let key = string.substring(start+1,end);
		
		string = string.slice(0,start) + ((key == "$random")?parseInt(Math.random()*100):userStorage[key]) + ((end != string.length-1)?string.slice(end+1):"");
	}
	
	return string;
	
}

function resolveBranch(branching){
		return ((resolveCondition(branching.condition))?((branching.targetBranching)?resolveBranch(branching.targetBranching):replaceTokensForValue(branching.target)):(branching.defaultBranching != undefined)?resolveBranch(branching.defaultBranching):replaceTokensForValue(branching.default));
}

function resolveCondition(condition){
	
	if(condition.value != undefined)
		condition.value = replaceTokensForValue(condition.value);
	
	if(condition.operator != undefined){
		switch(condition.operator){

			case "lessThan":
				return (number(userStorage[condition.key]) < number(condition.value));
			break;

			case "moreThan":
				return (number(userStorage[condition.key]) > number(condition.value));
			break;
			
			case "isSet":
				return (userStorage[condition.key] != undefined);
			break;
			
			case "isNotSet":
				return (userStorage[condition.key] == undefined);
			break;
			
			case "notEquals":
				return (userStorage[condition.key] != condition.value);
			break;
			
			case "equals":
			default:
				return (userStorage[condition.key] == condition.value);
			break;
		}
	}else{
		return (userStorage[condition.key] == condition.value);
	}
	
}

function showImage(image){
	
	if(image != undefined){
		
		let img = $("<img>");
		
		img.attr("src","./images/"+image.name);
		
		img.css("display","block");
		img.css("position","absolute");
		img.css("width",image.width+"px");
		img.css("height",image.height+"px");
		img.css("left",($(window).width()/2 - image.width/2)+"px");
		img.css("top",($(window).height()/2 - image.height/1.5)+"px");
		$("#canvas").append(img);
		
	}
	
}

function saveState(checkPoint){
	
	if(isSaveEnabled)
		if(checkPoint != undefined)
			if(checkPoint)
				window.localStorage.setItem("userStorage",JSON.stringify(userStorage));
	
}