/*
	This file contains the initial state of the program.
	If you activate the save function (yet to be implemented) the initial state will be replace by the saved state when the program is started.
*/
var userStorage = {};
var fadeSpeed = 500;
var isSaveEnabled = false;
var key = null;