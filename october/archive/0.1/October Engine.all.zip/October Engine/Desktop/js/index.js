$(() => {
	if(isSaveEnabled){
		let savedUserState = window.localStorage.getItem("userStorage");
		if(savedUserState != undefined){
			userStorage = JSON.parse(savedUserState);
		}
	}
	loadScript("main");

});