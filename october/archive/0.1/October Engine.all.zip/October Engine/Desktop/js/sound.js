let audio = undefined;

function musicPlay(audioTrack){
	if(audio != undefined){
		if(audio.playing()){
			audio.fade(audio.volume(),0,fadeSpeed);
			audio.on("fade",() => {
				audio = new Howl({
      					src: ["./music/"+audioTrack],
					autoplay: true,
  					loop: true,
    				});
				audio.play();
				audio.off("fade");
			});
			return;
		}
	}		
	audio = new Howl({
      		src: ["./music/"+audioTrack],
		autoplay: true,
  		loop: true,
    	});
	audio.play();
}

function musicStop(){
	if(audio != undefined){
		audio.fade(audio.volume(),0,fadeSpeed);
		audio.on("fade",() => {
			audio.stop();
			audio.off("fade");
		});
	}
}

function soundPlay(audioTrack){
	let sound = new Howl({
      		src: ["./music/"+audioTrack],
		autoplay: true,
  		loop: false,
    	});
	sound.play();
	return sound;
}