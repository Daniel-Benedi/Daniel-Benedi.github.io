class Localization{
    
    constructor(){
        this.currentLanguage = "default";
        this.availableLanguages = [];
    }

    getCurrentLanguage(){
        return this.currentLanguage;
    }

    setCurrentLanguage(currentLanguage){
        this.currentLanguage = currentLanguage;
    }

    getAvailableLanguages(){
        return this.availableLanguages;
    }

}