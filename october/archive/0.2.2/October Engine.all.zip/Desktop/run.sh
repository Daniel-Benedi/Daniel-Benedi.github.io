#!/bin/bash
echo Running game
npm start