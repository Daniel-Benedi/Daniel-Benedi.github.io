class Sound{

	constructor(){
		let audio = undefined;
	}

	musicPlay(audioTrack){
		if(this.audio != undefined){
			if(this.audio.playing()){
				this.audio.fade(this.audio.volume(),0,fadeSpeed);
				this.audio.on("fade",(() => {
					this.audio = new Howl({
							  src: ["./music/"+audioTrack],
						autoplay: true,
						  loop: true,
						});
					this.audio.play();
					this.audio.off("fade");
				}).bind(this));
				return;
			}
		}
		this.audio = new Howl({
				  src: ["./music/"+audioTrack],
			autoplay: true,
			  loop: true,
			});
		this.audio.play();
	}
	
	musicStop(){
		if(this.audio != undefined){
			this.audio.fade(this.audio.volume(),0,fadeSpeed);
			this.audio.on("fade",(() => {
				this.audio.stop();
				this.audio.off("fade");
			}).bind(this));
		}
	}
	
	soundPlay(audioTrack){
		let sound = new Howl({
				  src: ["./music/"+audioTrack],
			autoplay: true,
			  loop: false,
			});
		sound.play();
		return sound;
	}

}