#!/bin/bash
echo Compiling game for Windows
npm run-script winCompile