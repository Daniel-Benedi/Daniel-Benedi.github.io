#!/bin/bash
echo Compiling game for Mac OS
npm run-script macCompile