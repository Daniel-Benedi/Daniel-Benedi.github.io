#!/bin/bash
echo Compiling game for Linux
npm run-script linCompile