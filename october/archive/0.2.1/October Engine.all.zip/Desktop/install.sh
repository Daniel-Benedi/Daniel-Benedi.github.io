#!/bin/bash
echo Installing Dependencies
npm install
echo Dependencies Installed