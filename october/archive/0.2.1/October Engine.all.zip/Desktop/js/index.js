let engine ={
	sound:new Sound(),
	localization:new Localization()
};
$(() => {
	let savedLanguage = window.localStorage.getItem("language");
	if(savedLanguage != undefined && savedLanguage != "" && savedLanguage != null){
		engine.localization.setCurrentLanguage(savedLanguage);
	}
	if(isSaveEnabled){
		let savedUserState = window.localStorage.getItem("userStorage");
		if(savedUserState != undefined){
			userStorage = JSON.parse(savedUserState);
		}
	}
	loadScript("main");

});
