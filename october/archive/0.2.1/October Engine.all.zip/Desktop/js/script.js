let currentSound = undefined;

function loadScript(scriptName){
	if(scriptName.includes(".") || scriptName.includes("..")){
		alert("You cannot exit the script folder using loadScript");
	}else{
		if(key != null && key != undefined){
			$.get("./script/"+scriptName+".enc",null,(data)=>{
					currentScript = scriptName;
					runScriptObject(JSON.parse(CryptoJS.AES.decrypt(data, key).toString(CryptoJS.enc.Utf8)));
			});
		}else{
			$.getJSON("./script/"+scriptName+".json",null,(data)=>{
				currentScript = scriptName;
				runScriptObject(data);
			});
		}
	
	}
}

function runScriptObject(data){
	
	$("#canvas").off();
	$("#canvas").empty();
	
	if(data.background.includes(".."))
		data.background = "none";
		
	$("#canvas").css("background-image","url(\"./images/background/"+data.background+"\")");
	
	saveState(data.checkPoint);
	
	if(data.musicStart != undefined)
		engine.sound.musicPlay(data.musicStart);
	else if (data.musicStop != undefined)
		engine.sound.musicStop();
	
	if(currentSound != undefined)
		if(currentSound.playing())
			currentSound.stop();
		
	if(data.soundPlay != undefined)
		currentSound = engine.sound.soundPlay(data.soundPlay);
	
	switch(data.type){
		
		case "wait":
			waitScript(data);
		break;
		
		case "choice":
			choiceScript(data);
		break;
		
		case "text":
			textScript(data);
		break;
		
		case "input":
			inputScript(data);
		break;

		case "internal":
			internalScript(data);
		break;
		
		case "interactive":
			interactiveScript(data);
		break;
		
		default:
		
		break;
		
	}

}

function internalScript(data){
	if(data.value != undefined)
		setKey(data.key,data.value);
	else if(data.add != undefined)
		addToKey(data.key,data.add);
	else if(data.substract != undefined)
		substractToKey(data.key,data.substract);
	if(data.target != undefined){
		data.target = replaceTokensForValue(data.target);
	}else{
		if(data.branching != undefined){
			data.target = resolveBranch(data.branching);
		}
	}
	loadScript(data.target);
}

function waitScript(data){
	data.target = replaceTokensForValue(data.target);
	
	if(data.noFadeIn != undefined){
		if(!data.noFadeIn)
			$("#canvas").fadeIn(fadeSpeed);
	}else{
		$("#canvas").fadeIn(fadeSpeed);
	}
	showImage(data.image);
	let timeout = setTimeout(() =>{ 
			if(data.noFadeOut != undefined){
				if(!data.noFadeOut){
					$("#canvas").fadeOut(fadeSpeed,undefined, () => {
						if(data.value != undefined)
							setKey(data.key,data.value);
						else if(data.add != undefined)
							addToKey(data.key,data.add);
						else if(data.substract != undefined)
							substractToKey(data.key,data.substract);
						loadScript(data.target);
					} );
				}else{
					if(data.value != undefined)
						setKey(data.key,data.value);
					else if(data.add != undefined)
						addToKey(data.key,data.add);
					else if(data.substract != undefined)
						substractToKey(data.key,data.substract);
					loadScript(data.target);					
				}
			}else{
				$("#canvas").fadeOut(fadeSpeed,undefined, () => {
					if(data.value != undefined)
						setKey(data.key,data.value);
					else if(data.add != undefined)
						addToKey(data.key,data.add);
					else if(data.substract != undefined)
						substractToKey(data.key,data.substract);
					loadScript(data.target);
				} );
			}
		}
		,
		(data.timeout != undefined)?Number(data.timeout):1000);
	if(data.skippable != undefined)
		if(data.skippable)
			$("#canvas").click(() => {
				clearTimeout(timeout);
				if(data.noFadeOut != undefined){
					if(!data.noFadeOut){
						$("#canvas").fadeOut(fadeSpeed,undefined, () => {
							if(data.value != undefined)
								setKey(data.key,data.value);
							else if(data.add != undefined)
								addToKey(data.key,data.add);
							else if(data.substract != undefined)
								substractToKey(data.key,data.substract);
							
							loadScript(data.target);
						} );
					}else{
						if(data.value != undefined)
							setKey(data.key,data.value);
						else if(data.add != undefined)
							addToKey(data.key,data.add);
						else if(data.substract != undefined)
							substractToKey(data.key,data.substract);
						
						loadScript(data.target);						
					}
				}else
					$("#canvas").fadeOut(fadeSpeed,undefined, () => {
						if(data.value != undefined)
							setKey(data.key,data.value);
						else if(data.add != undefined)
							addToKey(data.key,data.add);
						else if(data.substract != undefined)
							substractToKey(data.key,data.substract);
						
						loadScript(data.target);
					} );
			});
	
}

function choiceScript(data){
	
	if(data.noFadeIn != undefined){
		if(!data.noFadeIn)
			$("#canvas").fadeIn(fadeSpeed);
	}else{
		$("#canvas").fadeIn(fadeSpeed);
	}
	
	let choices = data.choices;
	
	let choiceContainer = $("<div>");
	
	for(let i = 0; i < choices.length;i++){
		
		let currentChoice = $("<button>");

		if(engine.localization.getCurrentLanguage() != "default" && choices[i].localization != undefined){
			for(let j = 0; j < choices[i].localization.length;j++){
				if(choices[i].localization[j].language == engine.localization.getCurrentLanguage()){
					choices[i].text = choices[i].localization[j].text;
					break;
				}
			}
		}

		choices[i].text = replaceTokensForValue(choices[i].text);
		
		if(choices[i].target != undefined)
			choices[i].target = replaceTokensForValue(choices[i].target);
		
		currentChoice.text(choices[i].text);
		
		if(data.color != undefined)
			currentChoice.css("color",data.color);
		
		if(data.noborder != undefined)
			if(data.noborder)
				currentChoice.css("border-style","none");
		
		switch(choices[i].type){
			
			case "exit":
				currentChoice.click(() =>electron.ipcRenderer.invoke('winClose'));
			break;
			
			case "redirect":
				currentChoice.click( () =>{
					$("button").prop("disabled",true);
					engine.sound.soundPlay("buttonClick.mp3");
					
					if(choices[i].value != undefined)
						setKey(choices[i].key,choices[i].value);
					else if(choices[i].add != undefined)
						addToKey(choices[i].key,choices[i].add);
					else if(choices[i].substract != undefined)
						substractToKey(choices[i].key,choices[i].substract);
					
					if(choices[i].language != undefined)
						engine.localization.setCurrentLanguage(choices[i].language);

					if(choices[i].noFadeOut != undefined)
						if(!choices[i].noFadeOut)
							$("#canvas").fadeOut(fadeSpeed,undefined, () => loadScript(choices[i].target) );
						else
							loadScript(choices[i].target);
					else
						$("#canvas").fadeOut(fadeSpeed,undefined, () => loadScript(choices[i].target) ); 				
					
				});
			
			break;

			case "language":
				currentChoice.click(() =>{
					$("button").prop("disabled",true);
					engine.sound.soundPlay("buttonClick.mp3");
					if(engine.localization.getAvailableLanguages().indexOf(engine.localization.getCurrentLanguage()) == (engine.localization.getAvailableLanguages().length-1)){
						engine.localization.setCurrentLanguage("default");
					}else{
						engine.localization.setCurrentLanguage(engine.localization.getAvailableLanguages()[engine.localization.getAvailableLanguages().indexOf(engine.localization.getCurrentLanguage)+1]);
					}
					window.localStorage.setItem("language",engine.localization.getCurrentLanguage());
					loadScript(currentScript);
				});
			break;
			
			default:
			
			break;
			
		}
		
		if(choices[i].condition != undefined){
			if(resolveCondition(choices[i].condition))
				choiceContainer.append(currentChoice);
		}else
			choiceContainer.append(currentChoice);
		
	}
	
	$("#canvas").empty();
	
	$("#canvas").append(choiceContainer);
	
}

function textScript(data){
	
	if(data.noFadeIn != undefined){
		if(!data.noFadeIn)
			$("#canvas").fadeIn(fadeSpeed);
	}else{
		$("#canvas").fadeIn(fadeSpeed);
	}
	
	if(engine.localization.getCurrentLanguage() != "default" && data.localization != undefined){
		for(let i = 0; i < data.localization.length;i++){
			if(data.localization[i].language == engine.localization.getCurrentLanguage()){
				data.text = data.localization[i].text;
				break;
			}
		}
	}

	data.text = replaceTokensForValue(data.text);
	
	let text = $("<p>");
	
	text.css("z-index",999);
	
	if(data.color != undefined)
		text.css("color",data.color);
	
	text.attr("id","texto");
	
	showImage(data.image);
	
	$("#canvas").append(text);
	
	let task = setInterval(() => {renderText(text,data.text)}, 40);
	
	$("#canvas").off();
	$("#canvas").click(()=>fullTextOrLoad(task,data));
	
}

function inputScript(data){
	
	if(data.noFadeIn != undefined){
		if(!data.noFadeIn)
			$("#canvas").fadeIn(fadeSpeed);
	}else{
		$("#canvas").fadeIn(fadeSpeed);
	}
	
	let inputContainer = $("<div>");
	
	let input = $("<input>");
	
	input.attr("type","text");
	
	input.attr("placeholder",data.placeholder);
	
	let enterButton = $("<button>");

	enterButton.text(">");
	
	if(data.color != undefined){
		input.css("color",data.color);
		enterButton.css("color",data.color);
	}
	if(data.noborder != undefined){
		if(data.noborder){
			input.css("border-style","none");
			enterButton.css("border-style","none");
		}
	}
	
	let confirmInput = () =>{
		if(input.val() != ""){
			
			userStorage[data.key] = input.val();
			data.target = replaceTokensForValue(data.target);
			
			if(data.noFadeOut != undefined)
				if(!data.noFadeOut)
					$("#canvas").fadeOut(fadeSpeed,undefined, () => loadScript(data.target) );
				else
					loadScript(data.target);
			else
				$("#canvas").fadeOut(fadeSpeed,undefined, () => loadScript(data.target) );
		}
	};
	
	enterButton.click(confirmInput);
	input.keypress((e) =>{
		if(e.code == "Enter")
			confirmInput();
	});
	
	inputContainer.append(input);
	inputContainer.append(enterButton);
	
	$("#canvas").append(inputContainer);
}

function interactiveScript(data){
	
	if(data.noFadeIn != undefined){
		if(!data.noFadeIn)
			$("#canvas").fadeIn(fadeSpeed);
	}else{
		$("#canvas").fadeIn(fadeSpeed);
	}
	
	for(let i = 0; i < data.sprites.length;i++){
		let currentSprite = data.sprites[i];
		let showFlag = false;
		if(currentSprite.condition != undefined)
			showFlag = resolveCondition(currentSprite.condition);
		else
			showFlag = true;
		if(showFlag){
			let sprite = $("<img>");
			sprite.css("position","absolute");
			sprite.css("left",currentSprite.position.x);
			sprite.css("top",currentSprite.position.y);
			sprite.css("width",currentSprite.size.x);
			sprite.css("height",currentSprite.size.y);
			if(currentSprite.zindex != undefined)
				sprite.css("z-index",currentSprite.zindex);
			if(currentSprite.cursor != undefined)
				sprite.css("cursor",currentSprite.cursor);			
			sprite.attr("src","./images/sprites/"+currentSprite.img);
			sprite.click(() => {
				
				if(currentSprite.value != undefined)
					setKey(currentSprite.key,currentSprite.value);
				else if(currentSprite.add != undefined)
					addToKey(currentSprite.key,currentSprite.add);
				else if(currentSprite.substract != undefined)
					substractToKey(currentSprite.key,currentSprite.substract);
				
				if(currentSprite.noFadeOut != undefined)
					if(!currentSprite.noFadeOut)
						$("#canvas").fadeOut(fadeSpeed,undefined, () =>{
							if(currentSprite.branching == undefined)
								loadScript(currentSprite.target); 
							else
								loadScript(resolveBranch(currentSprite.branching));
						});
					else
						if(currentSprite.branching == undefined){
							loadScript(currentSprite.target); 
						}else{
							loadScript(resolveBranch(currentSprite.branching));
						}
				else
					$("#canvas").fadeOut(fadeSpeed,undefined, () =>{
						if(currentSprite.branching == undefined){
							loadScript(currentSprite.target); 
						}else{
							loadScript(resolveBranch(currentSprite.branching));
						}
					});
			});
			$("#canvas").append(sprite);
		}
	}
	
}
